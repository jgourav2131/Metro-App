# Delhi Metro Path Finder

## Python and Tkinter GUI

Python project on finding Best and Shortest Route to Travel in Delhi Metro with User-Friendly GUI made using Tkinter. Graphs Data Structure and Breadth-First Search were used for finding the Metro Route.
